-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 28, 2024 at 02:33 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lostandfounddb`
--

-- --------------------------------------------------------

--
-- Table structure for table `enquirymaster`
--

CREATE TABLE `enquirymaster` (
  `enquiryid` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `emailid` varchar(60) NOT NULL,
  `mobileno` varchar(15) NOT NULL,
  `message` varchar(250) NOT NULL,
  `enquiry_dt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `enquirymaster`
--

INSERT INTO `enquirymaster` (`enquiryid`, `name`, `emailid`, `mobileno`, `message`, `enquiry_dt`) VALUES
(1, 'Abhishek Singh', 'officialabhi9151@gmail.com', '123456789', 'wertyujk', '2024-09-18 13:48:52'),
(2, 'Abhishek Singh', 'officialabhi9151@gmail.com', '12345678', 'ertuyiodm', '2024-09-18 13:49:26'),
(3, 'Abhishek Singh', 'officialabhi9151@gmail.com', '1234567890', 'tyuifghjn ', '2024-09-18 13:52:25'),
(4, 'Abhishek Singh', 'officialabhi9151@gmail.com', '9151105889', 'hyy abhi', '2024-09-18 13:53:03'),
(5, 'Abhishek Singh', 'officialabhi9151@gmail.com', '9151105889', 'hello my name is abhishek singh', '2024-09-25 17:24:37'),
(6, 'Deepika Shukla', 'deepikasatr@gmail.com', '6789045678', 'I need help to found my laptop.', '2024-09-26 12:42:37'),
(7, 'Deepika Shukla', 'deepikasatr@gmail.com', '6789045678', 'I need help to found my laptop.', '2024-09-26 12:45:13'),
(8, 'Kishan maurya', 'kishanmauryavns252@gmail.com', '7393025005', 'i lost  my iPhone. Please help me', '2024-09-27 14:27:01');

-- --------------------------------------------------------

--
-- Table structure for table `feedbackmaster`
--

CREATE TABLE `feedbackmaster` (
  `f_id` int(11) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `feedback_title` varchar(100) NOT NULL,
  `feedback_text` varchar(400) NOT NULL,
  `f_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedbackmaster`
--

INSERT INTO `feedbackmaster` (`f_id`, `user_id`, `feedback_title`, `feedback_text`, `f_date`) VALUES
(1, 'abc@gmail.com', 'Regarding lost thing', 'This is such a nice portal. It helped me to find me lost earphone. Thanks to whole team of Lost and Found.', '2024-09-26 10:23:28'),
(2, 'abc@gmail.com', 'I found my iPhone', 'This is such a nice portal. It helped me to find me lost earphone. Thanks to whole team of Lost and Found.', '2024-09-26 10:26:01'),
(3, 'abc@gmail.com', 'Thanks for support', 'This is such a nice portal. It helped me to find me lost earphone. Thanks to whole team of Lost and Found.', '2024-09-26 10:27:49'),
(4, 'abc@gmail.com', 'Lost iPhone', 'i has lost iPhone but your team is very sportive , so thank you.', '2024-09-28 03:17:11'),
(5, 'abc@gmail.com', 'phone', 'thank you for ', '2024-09-28 12:26:51');

-- --------------------------------------------------------

--
-- Table structure for table `loginmaster`
--

CREATE TABLE `loginmaster` (
  `userid` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loginmaster`
--

INSERT INTO `loginmaster` (`userid`, `password`, `usertype`) VALUES
('a@gmail.com', '', 'STUDENT'),
('aa@gmail.com', '345', 'STUDENT'),
('abc@gmail.com', '345', 'USER'),
('abhi@gmail.com', '3', 'ADMIN'),
('abhisheksingh915110@gmail.com', '', 'STUDENT'),
('m@gmail.com', '345', 'STUDENT'),
('n@gmail.com', '', 'STUDENT'),
('null', '345', 'USER'),
('official@gmail.com', 'Z@4228', 'USER'),
('qq@gmail.com', '34567', 'USER'),
('v@gmail.com', ';373', 'STUDENT');

-- --------------------------------------------------------

--
-- Table structure for table `lostfoundmaster`
--

CREATE TABLE `lostfoundmaster` (
  `lostfound_id` int(11) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `post_type` varchar(20) NOT NULL,
  `category` varchar(80) NOT NULL,
  `specify_address` varchar(200) NOT NULL,
  `pincode` int(11) NOT NULL,
  `discription` varchar(300) NOT NULL,
  `picname` varchar(200) NOT NULL,
  `insedent_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lostfoundmaster`
--

INSERT INTO `lostfoundmaster` (`lostfound_id`, `user_id`, `post_type`, `category`, `specify_address`, `pincode`, `discription`, `picname`, `insedent_date`) VALUES
(1, 'abc@gmail.com', 'lost', 'documents', 'Dildarnagar', 232326, 'dfghj', 'india-gov-logo.png', '2024-09-25 14:43:44'),
(2, 'abc@gmail.com', 'lost', 'electronics', 'Dildarnagar', 232326, 'qwergh', 'mygov-footer-logo.png', '2024-09-25 14:44:05'),
(3, 'abc@gmail.com', 'lost', 'electronics', 'Dildarnagar', 232326, 'qwergh', 'mygov-footer-logo.png', '2024-09-25 14:44:21'),
(4, 'abc@gmail.com', 'lost', 'jewelry', 'Dildarnagar', 232326, 'sdfghj', 'india-gov-logo.png', '2024-09-25 14:45:44'),
(5, 'abc@gmail.com', 'lost', 'documents', 'Dildarnagar', 232326, 'sdfg', '8.png', '2024-09-25 14:49:52'),
(6, 'abc@gmail.com', 'lost', 'documents', 'Dildarnagar', 232326, 'kjdhkehk', '9.png', '2024-09-25 14:55:53'),
(7, 'abc@gmail.com', 'found', 'documents', 'Dildarnagar', 232326, 'ertyuk', '8.png', '2024-09-25 15:01:39'),
(8, 'abc@gmail.com', 'lost', 'electronics', 'Garib nawaz nagar kathi road', 232326, 'sdfgh', '8.png', '2024-09-25 15:05:20'),
(9, 'abc@gmail.com', 'lost', 'electronics', 'Garib nawaz nagar kathi road', 232326, 'sdfgh', '8.png', '2024-09-25 15:07:09'),
(10, 'abc@gmail.com', 'lost', 'documents', 'Garib nawaz nagar kathi road', 232326, 'ytrew', '5.png', '2024-09-25 15:07:36'),
(11, 'abc@gmail.com', 'lost', 'documents', 'Dildarnagar', 232326, 'asdfg', 'nic.png', '2024-09-25 17:14:17'),
(12, 'abc@gmail.com', 'lost', 'documents', 'Dildarnagar', 232326, 'fghjkl', '1.png', '2024-09-26 04:44:05'),
(13, 'abc@gmail.com', 'lost', 'clothing', 'chitrakoot kss', 232326, 'kss is best industry in IT company.', 'abhi.jpeg', '2024-09-27 12:03:19'),
(14, 'abc@gmail.com', 'found', 'jewelry', 'chitrakoot kss', 823673, 'i lost jewelry.', 'abhi1.png', '2024-09-27 13:01:16'),
(15, 'abc@gmail.com', 'found', 'clothing', 'chandani chauk market dilhi', 4567765, 'I lost cloth, so please help me.', 'study.jpg', '2024-09-28 03:14:25'),
(16, 'abc@gmail.com', 'lost', 'documents', 'Dildarnagar', 4567765, 'i lost my bag.', 'search.png', '2024-09-28 11:54:51'),
(17, 'abc@gmail.com', 'found', 'electronics', 'Dildarnagar', 232326, 'i lost Iphone', 'enquirybg.png', '2024-09-28 12:24:38');

-- --------------------------------------------------------

--
-- Table structure for table `newsmaster`
--

CREATE TABLE `newsmaster` (
  `newsid` int(11) NOT NULL,
  `newsmsg` varchar(300) NOT NULL,
  `postedon` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `newsmaster`
--

INSERT INTO `newsmaster` (`newsid`, `newsmsg`, `postedon`) VALUES
(19, 'There are varoius community groups dedicated to lost and found items, especially for pets or specific regions.', '2024-09-24 18:27:17'),
(20, 'These sites are tailored for finding lost pets and allow you to create posters and alert local shelters.', '2024-09-24 18:37:18'),
(21, 'These sites are tailored for finding lost pets and allow you to create posters and alert local shelters.', '2024-09-24 18:37:27'),
(22, 'These sites are tailored for finding lost pets and allow you to create posters and alert local shelters.', '2024-09-24 18:37:31'),
(23, 'A service that helps to find lost items, often linked to airports, hotels, and transportation.', '2024-09-24 18:39:12'),
(29, 'dfghjk', '2024-09-28 12:29:27');

-- --------------------------------------------------------

--
-- Table structure for table `rewardmaster`
--

CREATE TABLE `rewardmaster` (
  `rno` int(11) NOT NULL,
  `insedentid` int(11) NOT NULL,
  `amount` float NOT NULL,
  `paymode` varchar(25) NOT NULL,
  `paydetails` varchar(200) NOT NULL,
  `remark` varchar(300) NOT NULL,
  `reward_dt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rewardmaster`
--

INSERT INTO `rewardmaster` (`rno`, `insedentid`, `amount`, `paymode`, `paydetails`, `remark`, `reward_dt`) VALUES
(1, 0, 2000, 'cash', 'hii', 'dfghj', '2024-09-26 16:00:04'),
(2, 0, 1000, 'card', 'India Post Payment Bank', 'dildarnagar', '2024-09-26 17:54:46'),
(3, 12, 5000, 'online', 'payment on cash mode', 'post payment bank', '2024-09-26 17:57:47'),
(4, 12, 5000, 'online', 'payment on cash mode', 'post payment bank', '2024-09-26 17:57:52'),
(5, 11, 4000, 'cash', 'cash on delivery', 'dildarnagar', '2024-09-26 18:06:29'),
(6, 11, 4000, 'cash', 'cash on delivery', 'dildarnagar', '2024-09-26 18:07:51'),
(7, 11, 3000, 'card', 'online', 'ghazipur', '2024-09-26 18:08:17'),
(8, 0, 2000, 'cash', 'hii', 'dfghj', '2024-09-26 18:13:30'),
(9, 0, 2000, 'cash', 'hii', 'dfghj', '2024-09-26 18:13:32'),
(10, 0, 10000, 'card', 'ippb ', 'ghazipur', '2024-09-26 18:14:01'),
(11, 0, 10000, 'card', 'ippb ', 'ghazipur', '2024-09-26 18:15:40'),
(12, 0, 2000, 'cash', 'hii', 'dfghj', '2024-09-26 18:15:47'),
(13, 0, 70000, 'cash', ' payment', 'up', '2024-09-26 18:16:48'),
(14, 0, 70000, 'cash', ' payment', 'up', '2024-09-26 18:16:54'),
(15, 0, 2500, 'online', 'fggfew', 'goog project', '2024-09-26 18:24:51'),
(16, 12, 5000, 'online', 'payment on cash mode', 'post payment bank', '2024-09-26 18:30:25'),
(17, 12, 5000, 'online', 'payment on cash mode', 'post payment bank', '2024-09-26 18:30:28'),
(18, 0, 7500, 'cash', 'cashback', 'dildarnagar', '2024-09-26 18:31:14'),
(19, 0, 7500, 'cash', 'cashback', 'dildarnagar', '2024-09-26 18:31:20'),
(20, 0, 7500, 'cash', 'cashback', 'dildarnagar', '2024-09-26 18:31:23'),
(21, 0, 7500, 'cash', 'cashback', 'dildarnagar', '2024-09-26 18:41:30'),
(22, 0, 7500, 'cash', 'cashback', 'dildarnagar', '2024-09-26 18:43:49'),
(23, 0, 7500, 'cash', 'cashback', 'dildarnagar', '2024-09-26 18:46:44'),
(24, 11, 3000, 'card', 'online', 'ghazipur', '2024-09-26 18:47:07'),
(25, 11, 3000, 'card', 'online', 'ghazipur', '2024-09-26 18:47:40'),
(26, 11, 3000, 'card', 'online', 'ghazipur', '2024-09-26 18:47:51'),
(27, 11, 3000, 'card', 'online', 'ghazipur', '2024-09-26 18:48:21'),
(28, 11, 3000, 'card', 'online', 'ghazipur', '2024-09-26 18:48:37'),
(29, 11, 500, 'card', 'online', 'ghazipur', '2024-09-26 18:49:07'),
(30, 0, 5000, 'card', 'online pay', 'dilhi', '2024-09-28 03:15:35'),
(31, 0, 3000, 'card', 'dftyu', 'fghj', '2024-09-28 12:26:06');

-- --------------------------------------------------------

--
-- Table structure for table `usermaster`
--

CREATE TABLE `usermaster` (
  `name` varchar(50) NOT NULL,
  `father_name` varchar(50) NOT NULL,
  `date_of_birth` varchar(30) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `mobileno` varchar(15) NOT NULL,
  `curr_address` varchar(250) NOT NULL,
  `per_address` varchar(250) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usermaster`
--

INSERT INTO `usermaster` (`name`, `father_name`, `date_of_birth`, `email_id`, `gender`, `mobileno`, `curr_address`, `per_address`, `reg_date`) VALUES
('abhishek singh', 'shiv', '25-08-2006', 'a@gmail.com', 'Male', '4355', 'gdfs', 'gds', '2024-09-22 04:09:52'),
('abhishek singh', 'shiv', '25-08-2006', 'aa@gmail.com', 'Male', '9151105889', 'vbnm', 'dfghjk', '2024-09-23 11:25:27'),
('abhishek kumar', 'shiv', '25-08-2006', 'abc@gmail.com', 'Male', '9151345678', '  									  									  									  									  									  									  									  									  									  									  									  									  									dildarnagar\r\n  								\r\n  								\r\n  								\r\n  								\r\n  								\r\n  								\r\n  								\r\n  								', '  									  									  									  									  									  									  									  									  									  									  									  									  									chitrakoot\r\n  								\r\n  								\r\n  								\r\n  								\r\n  								\r\n  								\r\n  								\r\n  								\r', '2024-09-28 12:27:50'),
('Abhishek Kumar', 'Abc Xyz', '25-08-2006', 'abhisheksingh915110@gmail.com', 'Male', '9151105889', 'Sitapur', 'Sitapur', '2024-09-26 13:03:01'),
('abhishek kumar', 'Abc Xyz', '25-08-2006', 'm@gmail.com', 'Male', '45678765456', 'Kss', 'kss', '2024-09-28 11:53:24'),
('nitish singh', 'hira lal', '03-05-2006', 'n@gmail.com', 'Male', '7234568952', 'noida', 'noida', '2024-09-28 03:10:26'),
('abhishek singh', 'shiv', '25-08-2006', 'qq@gmail.com', 'Male', '76890923', 'oueoquekn', 'dlajl', '2024-09-20 11:54:19'),
('vandana singh', 'shankar', '03-05-2006', 'v@gmail.com', 'Female', '9151105889', 'dildarNagar,Ghazipur', 'dildarNagar,Ghazipur', '2024-09-24 13:25:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `enquirymaster`
--
ALTER TABLE `enquirymaster`
  ADD PRIMARY KEY (`enquiryid`);

--
-- Indexes for table `feedbackmaster`
--
ALTER TABLE `feedbackmaster`
  ADD PRIMARY KEY (`f_id`);

--
-- Indexes for table `loginmaster`
--
ALTER TABLE `loginmaster`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `lostfoundmaster`
--
ALTER TABLE `lostfoundmaster`
  ADD PRIMARY KEY (`lostfound_id`);

--
-- Indexes for table `newsmaster`
--
ALTER TABLE `newsmaster`
  ADD PRIMARY KEY (`newsid`);

--
-- Indexes for table `rewardmaster`
--
ALTER TABLE `rewardmaster`
  ADD PRIMARY KEY (`rno`);

--
-- Indexes for table `usermaster`
--
ALTER TABLE `usermaster`
  ADD PRIMARY KEY (`email_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `enquirymaster`
--
ALTER TABLE `enquirymaster`
  MODIFY `enquiryid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `feedbackmaster`
--
ALTER TABLE `feedbackmaster`
  MODIFY `f_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `lostfoundmaster`
--
ALTER TABLE `lostfoundmaster`
  MODIFY `lostfound_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `newsmaster`
--
ALTER TABLE `newsmaster`
  MODIFY `newsid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `rewardmaster`
--
ALTER TABLE `rewardmaster`
  MODIFY `rno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
