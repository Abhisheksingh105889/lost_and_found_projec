package kss.LostandFound_Project.controller;

import java.sql.ResultSet;

import javax.servlet.http.HttpSession;

import org.apache.tomcat.util.log.UserDataHelper.Mode;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import kss.LostandFound_Project.modules.Cryptography;
import kss.LostandFound_Project.modules.DBManager;
import kss.LostandFound_Project.modules.Mailer;

@Controller
public class Admincontroller 
{
	String Result="",aid=null;
	String Message="",CommandText="";
	ResultSet rs=null;
	DBManager dm=new DBManager();
	@RequestMapping(value="/admin/welcome")
	public String openWelcome() 
	{
		return "adminzone/welcome";
	}
	@RequestMapping(value="/admin/email")
	public String openEmail() 
	{
		return "adminzone/sendemail";
	}
	@RequestMapping(value="/admin/send",method=RequestMethod.POST)
	public String sending(@RequestParam String sendto,
			@RequestParam String subject,@RequestParam String message,
			Model md) 
	{
		Mailer m=new Mailer();
		boolean res=m.sendMyEmail(sendto, subject, message);
		Result =res==true?"Email send successfully.":"Sorry! unable to send email.";
		md.addAttribute("msg",Result);
		return "adminzone/sendemail";
	}
	@RequestMapping(value="/admin/notification")
	public String openNotification(Model md,HttpSession ses) 
	{
		//add below 2 line in all serviceRequest methods
		if(ses.getAttribute("aid")==null)
			return "redirect:/Login";
		DBManager db=new DBManager();
		CommandText="Select * from newsmaster";
		ResultSet rs=db.executeSelect(CommandText);
		md.addAttribute("data",rs);
		return "adminzone/notification";
	}
	@RequestMapping(value="/admin/addnotification",method = RequestMethod.POST)
	public String saveNews(@RequestParam String message,Model md) 
	{
		DBManager db=new DBManager();
		CommandText="insert into newsmaster(newsmsg) values('"+message+"')";
		boolean b=db.executeInsertUpdateOrDelete(CommandText);
		Message=b==true?"Notification saved successfully.":"Sorry! unable to save notification.";
		md.addAttribute("msg",Message);
		CommandText="Select * from newsmaster";
		ResultSet rs=db.executeSelect(CommandText);
		md.addAttribute("data",rs);
		return "adminzone/notification";
	}
	@RequestMapping(value = "/admin/deletenotification")
	public String deletenoti(@RequestParam int ni,Model md)
	{
		DBManager db=new DBManager();
		CommandText="delete from newsmaster where newsid ='"+ni+"'";
		boolean res=db.executeInsertUpdateOrDelete(CommandText);
		Result=res==true?"Notification deleted successfully.":"Sorry! unable to delete your notification.";
		md.addAttribute("msg",Result);
		CommandText="Select * from newsmaster";
		ResultSet rs=db.executeSelect(CommandText);
		md.addAttribute("data",rs);
		return "adminzone/notification";
	}
	@RequestMapping(value = "/admin/logout")
	public String logout(HttpSession ses)
	{
		ses.removeAttribute("aid");           //removing user data from session
		ses.invalidate();                 //destroying session object
		return "redirect:/Login";
	}
	
	@RequestMapping(value = "/admin/enqmgmt")
	public String managEnq(Model md)
	{
		CommandText="Select * from enquirymaster order by enquiryid desc";
		rs=dm.executeSelect(CommandText);
		md.addAttribute("enq",rs);
		return "adminzone/manageenq";
	} 
	@RequestMapping(value = "/admin/usermgmt")
	public String managUser(Model md)
	{
		CommandText="Select * from usermaster order by reg_date desc";
		rs=dm.executeSelect(CommandText);
		md.addAttribute("user",rs);
		return "adminzone/manageuser";
	} 
	
	@RequestMapping(value = "/admin/reward")
	public String manageReward(Model md)
	{
		CommandText="Select * from rewardmaster order by insedentid desc";
		rs=dm.executeSelect(CommandText);
		md.addAttribute("reward",rs);
		return "adminzone/rewards";
	} 
	
	@RequestMapping(value = "/admin/viewlostfound")
	public String manageViewlostFound(Model md)
	{
		CommandText="Select * from lostfoundmaster order by lostfound_id desc";
		rs=dm.executeSelect(CommandText);
		md.addAttribute("viewlf",rs);
		return "adminzone/viewlostfoundmaterial";
	} 
	
	
	@RequestMapping(value="/admin/UpdateadminPass",method=RequestMethod.POST)
	public String updateNewPass(@RequestParam String CurPass,@RequestParam String NewPass,@RequestParam String ConfPass,HttpSession ses,Model md)
	{
		//add below 5 lines in all ServiceRequest methods
				if(ses.getAttribute("aid")==null)
					return "redirect:/Login";
				String s=getCurrentUserDetails();
				md.addAttribute("uname",s);
		if(NewPass.equals(ConfPass)==true)
		{
			Cryptography cg=new Cryptography();
			String epass=cg.encryptMyPassword(CurPass);
			//reading id of current user from session
			aid=ses.getAttribute("aid").toString();
			CommandText="Select * from loginmaster where userid='"+aid+"' and password='"+epass+"'";
			
			try
			{
				ResultSet rs=dm.executeSelect(CommandText);
				if(rs.next()==true)
				{
					epass=cg.encryptMyPassword(NewPass);
					CommandText="Update loginmaster set password='"+epass+"' where userid='"+aid+"'";
					boolean r=dm.executeInsertUpdateOrDelete(CommandText);
					if(r==true)
					{
						Result="Your password update successfully.";
					}
					else
						Result="Sorry! unable to update your password.";
				}
				else
					Result="Invalid current password. Please try again.";
			}
			catch (Exception e) {
				System.out.println("Error: "+e.getMessage());
				Result="Sorry! unable to update your password";
			}
		}
		else 
			Result="New password and confirm password must be same.";
			md.addAttribute("msg", Result);
			return "adminzone/changepassword";
	}
	
	private String getCurrentUserDetails() {
		// TODO Auto-generated method stub
		return null;
	}
	@RequestMapping(value="/admin/changeadinpass")
	public String openadminchangepass(HttpSession ses,Model md)
	{
		//add below 5 lines in all ServiceRequest methods
				if(ses.getAttribute("aid")==null)
					return "redirect:/Login";
				String s=getCurrentUserDetails();
				md.addAttribute("uname",s);
		return "adminzone/changepassword";
	}
	@RequestMapping(value="/admin/showfeed")
	public String showFeedback(Model md)
	{
		CommandText="Select *from feedbackmaster order by f_id desc";
		ResultSet rset=dm.executeSelect(CommandText);
		md.addAttribute("fdata",rset);
		return "adminzone/managefeed";
	}
}
