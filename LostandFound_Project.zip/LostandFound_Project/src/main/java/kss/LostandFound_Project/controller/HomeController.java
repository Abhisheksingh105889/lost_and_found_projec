package kss.LostandFound_Project.controller;

import java.io.IOException;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import kss.LostandFound_Project.modules.Cryptography;
import kss.LostandFound_Project.modules.DBManager;
import kss.LostandFound_Project.modules.Mailer;
import kss.LostandFound_Project.modules.usermaster;

@Controller
public class HomeController 
{
	    String result=null;
		@RequestMapping(value = "/")
		public String test(Model md)
		{
			// To display dynamic update...
			DBManager dm=new DBManager();
			String cmd="Select newsmsg from newsmaster order by newsid desc limit 3";
			ResultSet rs=dm.executeSelect(cmd);
			md.addAttribute("noti",rs);
			return "index";
		}
	@RequestMapping(value="/about")
	public String openAboutUs(Model md)
	{
		return "aboutus";
	}	
	@RequestMapping(value = "/ContactUs")
	public String openContacttUs()
	{
		return "ContactUs";
	}
	@RequestMapping(value = "/developer")
	public String openDeveloper()
	{
		return "developer";
	}
	@RequestMapping(value = "/Registration")
	public String openRegistration()
	{
		return "Registration";
	}
	@RequestMapping(value="/processlogin",method = RequestMethod.POST)
	public String checkLogin(@RequestParam String UserType, @RequestParam String UserId, @RequestParam String pass, Model md,HttpSession ses)
	{
		Cryptography cg=new Cryptography();
		String epass=cg.encryptMyPassword(pass);
		String cmd="Select *from loginmaster where userid='"+UserId+"' and 	password='"+epass+"' and usertype='"+UserType+"'";
		DBManager dm=new DBManager();
		ResultSet rs= dm.executeSelect(cmd);
		try
		{
			if(rs.next()==true)
			{
				// Create session and transfer into specific zone.
				if(UserType.equals("USER")==true)
				{
					//Transfer into user zone
					ses.setAttribute("uid", UserId);
					return "redirect:dashboard";
				}
				else
				{
					// transfer into admin zone
					ses.setAttribute("aid", UserId);
					return "redirect:admin/welcome";
				}
			}
			else
			{
				result="Invalid UserId or Password.";
			}
		}
		catch (Exception e) 
		{
			result="Sorry! unable to process your request.";
			System.out.println("Error: "+result);
		}
		md.addAttribute("msg",result);
		return "Login";
	}
	@RequestMapping(value="/saveReg",method=RequestMethod.POST)
	public String saveNewUser(Model md, @RequestParam String Pass,  @RequestParam String ConfPass,
			@RequestParam String CaptchaCode,@ModelAttribute usermaster sm,HttpSession ses)
	{
		String code=ses.getAttribute("CaptchaCode").toString();
		if(CaptchaCode.equals(code)==true)
		{
			if(Pass.equals(ConfPass)==true)
			{
			// Start: DB Code
				try
				{
					String cmd="Insert into usermaster(name,father_name,date_of_birth,email_id,gender,mobileno,curr_address,per_address) "
					+ "values ('"+sm.getName()+"','"+sm.getFather_name()+"','"+sm.getDate_of_birth()+"','"+sm.getEmail_id()+"','"+sm.getGender()+"','"+sm.getMobileno()+"','"+sm.getCurr_address()+"','"+sm.getPer_address()+"')";
					DBManager dm=new DBManager();
					boolean res=dm.executeInsertUpdateOrDelete(cmd);
					//Start: Setting Login details 
					
					Cryptography cg=new Cryptography();
					String epass=cg.encryptMyPassword(Pass);
					cmd="Insert into loginmaster values('"+sm.getEmail_id()+"','"+epass+"','STUDENT')";
					res=dm.executeInsertUpdateOrDelete(cmd);
					
					//End: Setting Login details 
					result=res==true?"Congratulations you are registered successfully.":"Sorry! unable to create your account.";
					//Sending email alert
		String mailmsg="Hi "+sm.getName()+",\n\nCongratulations!! you "
			+ "are registered successfully in Lost and Found Webportal."
			+ "Thanks to join our team.\n\nYour User Id: "+sm.getEmail_id()+
			"\nYour Password is: "+Pass+"\n\n\nFrom-\nTeam Lost and Found";
					Mailer ml=new Mailer();
					ml.sendMyEmail(sm.getEmail_id(), 
							"Greeting from Lost & Found", mailmsg);
				}
				catch (Exception e) {
					// TODO: handle exception
					result="Sorry! Unable to create your account. Please try again.";
					System.out.println("Error: "+e.getMessage());
				}
			//End: DB Code
			}
		}
		System.out.print(result);
		md.addAttribute("msg",result);
		return "Registration";
	}
	@RequestMapping(value = "/Login")
	public String openLogin()
	{
		return "Login";
	}
	@RequestMapping(value="/SaveEnquiry")
	public String saveEng(@RequestParam String Name,@RequestParam String EmailId,@RequestParam String MobileNo,@RequestParam String Query,Model md)
	{
		String MyCommand="insert into enquirymaster(name,emailid,mobileno,message) values('"+Name+"','"+EmailId+"','"+MobileNo+"','"+Query+"')";
		DBManager dm=new DBManager();
		boolean res=dm.executeInsertUpdateOrDelete(MyCommand);
		result=res==true?"Your enquiry saved successfully.":"Sorry! unable to save your enquiry.";
		md.addAttribute("msg",result);
		//Sending email alert
		String mailmsg="Hi "+Name+",\n\nThanks for your enquiry. "
+ "Our team will contact you shortly.\n\n\nFrom-\nTeam Lost and Found";
		Mailer ml=new Mailer();
		ml.sendMyEmail(EmailId, "Thank you for Enquiry", mailmsg);
		//to show notification
		// To display dynamic update...
					dm=new DBManager();
					String cmd="Select newsmsg from newsmaster order by newsid desc limit 3";
					ResultSet rs=dm.executeSelect(cmd);
					md.addAttribute("noti",rs);
		return "index";
	}
	
}
