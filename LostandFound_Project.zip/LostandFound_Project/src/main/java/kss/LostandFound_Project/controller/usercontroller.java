package kss.LostandFound_Project.controller;

import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.Locale.Category;

import javax.servlet.Servlet;
import javax.servlet.ServletRequestAttributeEvent;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import kss.LostandFound_Project.modules.Cryptography;
import kss.LostandFound_Project.modules.DBManager;
import kss.LostandFound_Project.modules.usermaster;

@Controller
public class usercontroller 
{
	DBManager dm=new DBManager();
	String commandText=null;
	String Result="",uid=null;
	String getCurrentUserDetails()
	{
		String uid;
		//Reading userid of current User from session...
		ServletRequestAttributes attr=(ServletRequestAttributes)RequestContextHolder.currentRequestAttributes();
		HttpSession ses=attr.getRequest().getSession();
		uid=ses.getAttribute("uid").toString();
		commandText="Select name from usermaster where email_id='"+uid+"'";
		ResultSet rs=dm.executeSelect(commandText);
		String s="";
		try
		{
			rs.next();
			s=rs.getString("name");
		}
		catch (Exception e) {
			System.out.println("Error: "+e.getMessage());
			
		}
		return s;
	}
	@RequestMapping(value="/dashboard")
	public String opendashboard(HttpSession ses,Model md)
	{
		//add below 5 lines in all ServiceRequest methods
		if(ses.getAttribute("uid")==null)
			return "redirect:/Login";
		String s=getCurrentUserDetails();
		md.addAttribute("uname",s);
		return "userzone/dashboard";
	}
	
	@RequestMapping(value="/UpdatePass",method=RequestMethod.POST)
	public String updateNewPass(@RequestParam String CurPass,@RequestParam String NewPass,@RequestParam String ConfPass,HttpSession ses,Model md)
	{
		//add below 5 lines in all ServiceRequest methods
				if(ses.getAttribute("uid")==null)
					return "redirect:/Login";
				String s=getCurrentUserDetails();
				md.addAttribute("uname",s);
		if(NewPass.equals(ConfPass)==true)
		{
			Cryptography cg=new Cryptography();
			String epass=cg.encryptMyPassword(CurPass);
			//reading id of current user from session
			uid=ses.getAttribute("uid").toString();
			commandText="Select * from loginmaster where userid='"+uid+"' and password='"+epass+"'";
			
			try
			{
				ResultSet rs=dm.executeSelect(commandText);
				if(rs.next()==true)
				{
					epass=cg.encryptMyPassword(NewPass);
					commandText="Update loginmaster set password='"+epass+"' where userid='"+uid+"'";
					boolean r=dm.executeInsertUpdateOrDelete(commandText);
					if(r==true)
					{
						Result="Your password update successfully.";
					}
					else
						Result="Sorry! unable to update your password.";
				}
				else
					Result="Invalid current password. Please try again.";
			}
			catch (Exception e) {
				System.out.println("Error: "+e.getMessage());
				Result="Sorry! unable to update your password";
			}
		}
		else 
			Result="New password and confirm password must be same.";
			md.addAttribute("msg", Result);
			return "userzone/changepassword";
	}
	
	@RequestMapping(value="/changepass")
	public String openchangepass(HttpSession ses,Model md)
	{
		//add below 5 lines in all ServiceRequest methods
				if(ses.getAttribute("uid")==null)
					return "redirect:/Login";
				String s=getCurrentUserDetails();
				md.addAttribute("uname",s);
		return "userzone/changepassword";
	}
	@RequestMapping(value="/profile")
	public String openprofile(HttpSession ses,Model md)
	{
		//add below 5 lines in all ServiceRequest methods
				if(ses.getAttribute("uid")==null)
					return "redirect:/Login";
				String s=getCurrentUserDetails();
				md.addAttribute("uname",s);
				ResultSet rs= showProfile(ses);
				md.addAttribute("udata",rs);
				return "userzone/profile";
	}
	@RequestMapping(value="/saveprofile",method = RequestMethod.POST)
	public String saveprofile(HttpSession ses,Model md,@ModelAttribute usermaster sm)
	{
		//add below 5 lines in all ServiceRequest methods
				if(ses.getAttribute("uid")==null)
					return "redirect:/Login";
				String s=getCurrentUserDetails();
				md.addAttribute("uname",s);
				try
				{
					// update in database
					uid=ses.getAttribute("uid").toString();
					commandText="Update usermaster set name='"+sm.getName()+"',	gender='"+sm.getGender()
					+"',father_name='"+sm.getFather_name()+"',date_of_birth='"+sm.getDate_of_birth()
					+"',mobileno='"+sm.getMobileno()+"',curr_address='"+sm.getCurr_address()
					+"',per_address='"+sm.getPer_address()+"' where email_id='"+uid+"'";
					boolean b=dm.executeInsertUpdateOrDelete(commandText);
					Result=b==true?"Your profile updated successfully.":"Sorry! unable to update your profile.";
					
				}
				catch (Exception e) 
				{
					System.out.println("Error: "+e.getMessage());
					Result="Sorry! unable to update your profile.";
				}
				s=getCurrentUserDetails();
				md.addAttribute("uname",s);
				md.addAttribute("msg", Result);
				ResultSet rs=showProfile(ses);
				md.addAttribute("udata",rs);
				return "userzone/profile";
	}
	ResultSet showProfile(HttpSession s)
	{
		commandText="Select * from usermaster where email_id='"+s.getAttribute("uid")+"'";
		ResultSet rs= dm.executeSelect(commandText);
		return rs;
	}
	
	@RequestMapping(value="/feedback")
	public String openfeedback(HttpSession ses,Model md)
	{
		//add below 5 lines in all ServiceRequest methods
		if(ses.getAttribute("uid")==null)
			return "redirect:/Login";
		String s=getCurrentUserDetails();
		md.addAttribute("uname",s);
		return "userzone/feedback";
	}
	@RequestMapping(value="/postfoundthing")
	public String openLostFoundThing(HttpSession ses,Model md)
	{
		//add below 5 lines in all ServiceRequest methods
		if(ses.getAttribute("uid")==null)
			return "redirect:/Login";
		String s=getCurrentUserDetails();
		md.addAttribute("uname",s);
		return "userzone/post&foundthing";
	}
	@RequestMapping(value="/savelostfound",method=RequestMethod.POST)
	public String savelostfound(HttpSession ses,Model md,@RequestParam CommonsMultipartFile picname,@RequestParam String posttype,@RequestParam String category,@RequestParam String address,@RequestParam String pincode,@RequestParam String discription)
	{
		//add below 5 lines in all ServiceRequest methods
		if(ses.getAttribute("uid")==null)
			return "redirect:/Login";
		String s=getCurrentUserDetails();
		md.addAttribute("uname",s);
		// For uploading.
		uid=ses.getAttribute("uid").toString();
		
		// Uploading file into server...
		if(picname!=null)
		{
			long fsize=picname.getSize();
			if(fsize>0)
			{
				String fname=picname.getOriginalFilename();
				String ext=fname.substring(fname.lastIndexOf('.')).toUpperCase();
				if(ext.equals(".JPG") || ext.equals(".PNG") || ext.equals(".JPEG"))
				{
					try 
					{
						byte []fileBytes=picname.getBytes();
						String FolderPath=ses.getServletContext().getRealPath("/")+"resources/goodspic";
						FileOutputStream fos=new FileOutputStream(FolderPath+"/"+fname);
						fos.write(fileBytes);
						fos.close();
						System.out.println("Path: "+FolderPath+"/"+fname);
						//DB insertion
						Result="sorry! unable to process your request";
						commandText="insert into lostfoundmaster(user_id,picname,post_type,category,specify_address,pincode,discription) values('"+uid+"','"+fname
								+"','"+posttype+"','"+category+"','"+address+"','"+pincode
								+"','"+discription+"')";
						boolean b=dm.executeInsertUpdateOrDelete(commandText);
						Result=b==true?"your incident of Lost/Found is posted successfully.":"Sorry! unable to upload picture";
					}
					catch (Exception e) 
					{
						System.out.println("Error: "+e.getMessage());
						Result="Sorry! due to some technical error, we are unable to process your request.";
					}
					
				}
				else
				Result="Invalid file type. Please choose an image.";
			}
			else
			{
				Result="Please choose a picture.";
			}
		}
		else
			Result="Sorry! unable to process your request.";
		md.addAttribute("msg",Result);
		return "userzone/post&foundthing";
	}
	@RequestMapping(value="/searchlostmaterial")
	public String openSearchLostMaterial(HttpSession ses,Model md)
	{
		//add below 5 lines in all ServiceRequest methods
		if(ses.getAttribute("uid")==null)
			return "redirect:/Login";
		String s=getCurrentUserDetails();
		md.addAttribute("uname",s);
		return "userzone/searchlostmaterial";
	}
	@RequestMapping(value="/search",method=RequestMethod.POST)
	public String searchLost(HttpSession ses,Model md,
			@RequestParam String searchvalue)
	{
		//add below 5 lines in all ServiceRequest methods
		if(ses.getAttribute("uid")==null)
			return "redirect:/Login";
		String s=getCurrentUserDetails();
		md.addAttribute("uname",s);
		//searching start
		commandText="Select *from lostfoundmaster where post_type like '%"+
		searchvalue+"%' or category like '%"+searchvalue+"%' or specify_address like '%"+
		searchvalue+"%' or pincode like '%"+searchvalue+"%' or discription like'%"+
		searchvalue+"%' or insedent_date like '%"+searchvalue
		+"%' order by lostfound_id desc";
		System.out.println("Command: "+commandText);
		ResultSet rss= dm.executeSelect(commandText);
		md.addAttribute("data",rss);
		return "userzone/searchlostmaterial";
	}
	@RequestMapping(value="/givereward")
	public String openGiveReward(HttpSession ses,Model md)
	{
		//add below 5 lines in all ServiceRequest methods
		if(ses.getAttribute("uid")==null)
			return "redirect:/Login";
		String s=getCurrentUserDetails();
		md.addAttribute("uname",s);
		return "userzone/givereward";
	}
	@RequestMapping(value="/savereward",method=RequestMethod.POST)
	public String saveReward(HttpSession ses,Model md,@RequestParam int lfid,
			@RequestParam float amount,@RequestParam String paymentMode,
			@RequestParam String paymentDetails,@RequestParam String remark)
	{
		//add below 5 lines in all ServiceRequest methods
				if(ses.getAttribute("uid")==null)
					return "redirect:/Login";
				String s=getCurrentUserDetails();
				md.addAttribute("uname",s);
				// DB code start to save reward...
				commandText="insert into rewardmaster(insedentid,amount,paymode,paydetails,"
				+ "remark) values ('"+lfid+"','"+amount+"','"+paymentMode+"','"+
				paymentDetails+"','"+remark+"')";
				boolean b=dm.executeInsertUpdateOrDelete(commandText);
				Result=b==true?"Thanks for your reward. Reward details saved successfully.":
				"Sorry! unable to save reward details.";
				md.addAttribute("msg",Result);
				return "userzone/givereward";
	}
	@RequestMapping(value="/myuploads")
	public String openMyUpload(HttpSession ses,Model md)
	{
		
		//add below 5 lines in all ServiceRequest methods
				if(ses.getAttribute("uid")==null)
					return "redirect:/Login";
				String s=getCurrentUserDetails();
				md.addAttribute("uname",s);
	   //Code to show my uploads
		String upby=ses.getAttribute("uid").toString();
		commandText="select * from lostfoundmaster where user_id='"+upby+"'";
		ResultSet rset=dm.executeSelect(commandText);
		md.addAttribute("data",rset);
		return "userzone/myuploads";
	}
	@RequestMapping(value="/saveFeedback",method=RequestMethod.POST)
	public String saveFeed(@RequestParam String title,@RequestParam String fmsg,
			Model md,HttpSession ses)
	{
		//add below 4 lines in all ServiceRequest methods
		if(ses.getAttribute("uid")==null)
			return "redirect:/Login";
		String s=getCurrentUserDetails();
		md.addAttribute("uname",s);
		String userid=ses.getAttribute("uid").toString();
		commandText="insert into feedbackmaster(user_id,feedback_title,feedback_text) values('"+
		userid+"','"+title+"','"+fmsg+"')";
		boolean res=dm.executeInsertUpdateOrDelete(commandText);
		Result=res==true?"Thanks for your valuable feedback.":"Sorry! unable to save your feedback.";
		md.addAttribute("msg",Result);
		return "userzone/feedback";
	}
	@RequestMapping(value = "/logout")
	public String logout(HttpSession ses)
	{
		ses.removeAttribute("uid");
		ses.invalidate();
		return "redirect:/Login";
	}
}
