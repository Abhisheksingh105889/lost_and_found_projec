package kss.LostandFound_Project.modules;

public class Cryptography 
{
	public String encryptMyPassword(String plainPassword)
	{
		String EncrytedPass="";
		int ASCIIVal,NewASCIIVal;
		for(int x=0;x<plainPassword.length();x++)
		{
			char ch=plainPassword.charAt(x);
			ASCIIVal=(int)ch;
			if(ASCIIVal>=65 && ASCIIVal<=90)
			{
				NewASCIIVal=65-ASCIIVal+90;
			}
			else if(ASCIIVal>=97 && ASCIIVal<=122)
			{
				NewASCIIVal=ASCIIVal+32;
			}
			else if(ASCIIVal>=48 && ASCIIVal<=57)
			{
				NewASCIIVal=ASCIIVal+2;
			}
			else
			{
				NewASCIIVal=ASCIIVal;
			}
			EncrytedPass=EncrytedPass+(char)NewASCIIVal;
		}
		return EncrytedPass;
	}
}
