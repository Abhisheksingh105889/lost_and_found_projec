package kss.LostandFound_Project.modules;

import java.util.Properties;

import org.springframework.mail.MailMessage;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;

public class Mailer 
{
   private String MyEmailId="officialabhi9151@gmail.com";
   private String MyAppPassword="lmtv fxtf tisl xtag";
   public boolean sendMyEmail(String SendTo,String Subject,String MessageBody)
   {
	   try 
	   {
		   //Step 1: Setting email protocol and configuration 
		   //by using Properties class
		   Properties p=new Properties();
		   p.put("mail.smtp.host","smtp.gmail.com");
		   p.put("mail.smtp.port", 465);
		   p.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		   p.put("mail.smtp.auth","true");
		   // Step 2: Setting email and password in MailSender 
		   JavaMailSenderImpl jmi=new JavaMailSenderImpl();
		   jmi.setJavaMailProperties(p);
		   jmi.setUsername(MyEmailId);
		   jmi.setPassword(MyAppPassword);
		   MailSender ms=jmi;
		   // Step 3: Setting mail message
		   SimpleMailMessage smi=new SimpleMailMessage();
		   smi.setTo(SendTo);
		   smi.setSubject(Subject);
		   smi.setText(MessageBody);
		   smi.setFrom(MyEmailId);
		   // Step 4: Send email
		   ms.send(smi);
		   return true;
	   }
	   catch (Exception e) {
		System.out.println("Error in mail Sending: "+e.getMessage());
		return false;
	}
   }
}
